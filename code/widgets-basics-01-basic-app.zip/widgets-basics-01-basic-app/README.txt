Important: This attached code is NOT a standalone project! You can’t run this extracted file. The iOS and Android folders would be too big to attach.

The complete Flutter/ Dart code is included though (in the lib/ folder). The currently used packages and project settings can be seen in the pubspec.yaml file.

Instead, use this code to compare it to yours. Feel free to also replace your code (temporarily) to find errors you might be facing.